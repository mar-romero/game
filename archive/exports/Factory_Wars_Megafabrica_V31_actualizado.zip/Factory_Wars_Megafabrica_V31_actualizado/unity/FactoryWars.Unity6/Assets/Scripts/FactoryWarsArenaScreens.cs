using System;
using UnityEngine;
using UnityEngine.UI;

namespace FactoryWars.Unity6
{
    public sealed partial class FactoryWarsMobileApp
    {
        private string[][] arenaCandidates;
        private string[] arenaBans;
        private GameObject arenaPicker;
        private Transform arenaCombatRoot;
        private int arenaCollectionFocusFamily = -1;
        private readonly Button[,] arenaCombatButtons = new Button[3, 2];
        private readonly System.Collections.Generic.List<GameObject> arenaFlightMarkers = new System.Collections.Generic.List<GameObject>();
        private GameObject arenaPlayerBarrierVisual, arenaEnemyBarrierVisual;
        private Image arenaFightTint;
        private float arenaFightViewportHeight;
        private static readonly string[][] ArenaIds = {
            new[] { "fast", "heavy", "burst", "piercing", "breaker", "emp", "vector", "exposed", "economical", "node" },
            new[] { "quick", "heavy", "interceptor", "sustained", "antiburst", "antipiercing", "regenerative", "reflection", "reinforced", "emergency" },
            new[] { "disrupt", "economy", "production", "cooldown", "launch", "ambush", "friction", "supplies", "reconfigure", "precision" }
        };

        private void InitArenaLoadout()
        {
            if (factoryV2Save == null) LoadFactoryV2();
            if (arenaCandidates != null) return;
            arenaCandidates = new[] { new[] { "fast", "heavy", "burst", "piercing" }, new[] { "quick", "heavy", "interceptor", "sustained" }, new[] { "disrupt", "economy", "production" } };
            arenaBans = new[] { "piercing", "sustained", "production" };
        }

        private void BuildArenaLobbyScreen()
        {
            InitArenaLoadout();
            Hero("ARENA", "TU FÁBRICA · TU ESTRATEGIA", "Práctica local contra un bot · sin clasificación", cyan);
            var art = Card("TU FÁBRICA", "Cohetes · escudos · sabotaje", 320);
            var image = Panel("Arena Factory Art", art.transform, Color.white);
            Anchor(image, new Vector2(.03f, .06f), new Vector2(.97f, .95f), Vector2.zero, Vector2.zero);
            var imageComponent = image.GetComponent<Image>(); imageComponent.enabled = false; imageComponent.raycastTarget = false;
            var raw = new GameObject("Arena own factory crop", typeof(RectTransform), typeof(RawImage)); raw.transform.SetParent(image.transform, false);
            Anchor(raw, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            var crop = raw.GetComponent<RawImage>(); crop.texture = Resources.Load<Texture2D>("FactoryWarsArenaLobby"); crop.uvRect = new Rect(0, .02f, 1, .45f); crop.color = Color.white;
            var rockets = FlowActionButton(raw.transform, "⚡ COHETES", new Color32(240, 128, 70, 245), () => OpenArenaCollectionFamily(0));
            Anchor(rockets.gameObject, new Vector2(0, .55f), new Vector2(.24f, .72f), Vector2.zero, Vector2.zero);
            var shields = FlowActionButton(raw.transform, "◈ ESCUDOS", cyan, () => OpenArenaCollectionFamily(1));
            Anchor(shields.gameObject, new Vector2(.76f, .55f), new Vector2(1, .72f), Vector2.zero, Vector2.zero);
            var sabotage = FlowActionButton(raw.transform, "⌁ SABOTAJE", new Color32(177, 120, 250, 245), () => OpenArenaCollectionFamily(2));
            Anchor(sabotage.gameObject, new Vector2(.35f, .05f), new Vector2(.65f, .22f), Vector2.zero, Vector2.zero);
            PlacedLabel(art.transform, "◈ ESCUDOS         ⚡ COHETES         ⌁ SABOTAJE", 10, cyan, FontStyle.Bold, TextAnchor.MiddleCenter,
                Vector2.zero, new Vector2(1, 0), new Vector2(5, 5), new Vector2(-5, 30));

            var loadout = Card("ARSENAL", "Elegí tus módulos antes de la práctica", 120);
            var body = CardBody(loadout.transform);
            FlowActionButton(body, "COLECCIÓN · ELEGIR ARSENAL", cyan, () => { arenaCollectionVisible = true; ShowSection(HubSection.Pvp); });
            var modes = Card("MODOS", "La práctica local está disponible en Unity.", 225);
            var modeBody = CardBody(modes.transform);
            FlowActionButton(modeBody, "JUGAR PRÁCTICA LOCAL", new Color32(72, 229, 202, 255), StartArenaLocalMatch);
            FlowActionButton(modeBody, "JUGAR COMPETITIVO · NO DISPONIBLE", muted, () => Notice("El competitivo y el matchmaking online todavía no están conectados a Unity."));
            FlowActionButton(modeBody, "JUGAR CAMPAÑA · NO DISPONIBLE", muted, () => Notice("La campaña todavía no está conectada a Unity."));
            ApplyArenaGlassStyle(content);
        }

        private void BuildArenaCollectionScreen()
        {
            InitArenaLoadout();
            Hero("COLECCIÓN", "PREPARÁ TU CARGA", "4 / 4 / 3 elegidos · 2 / 2 / 1 activos · módulos investigados en Megafábrica", cyan);
            for (int family = 0; family < 3; family++)
            {
                int f = family; var glyph = f == 0 ? "⚡ " : f == 1 ? "◈ " : "⌁ ";
                var card = Card(glyph + (f == arenaCollectionFocusFamily ? "◉ " : "") + ArenaCatalog.Names[f], "Tocá un espacio para elegir variante", 315);
                var body = CardBody(card.transform);
                for (int slot = 0; slot < ArenaCatalog.CandidateCounts[f]; slot++)
                {
                    int s = slot;
                    var button = FlowActionButton(body, "", cyan, () => CycleArenaCandidate(f, s));
                    LayoutElement(button.gameObject).preferredHeight = 44;
                    RefreshArenaLoadoutButton(button, f, s);
                }
                if (f < 3)
                {
                    var ban = FlowActionButton(body, "BLOQUEO: " + ArenaCatalog.Find(f, arenaBans[f]).Name + "   ›", muted, () => CycleArenaBan(f));
                    LayoutElement(ban.gameObject).preferredHeight = 38;
                }
            }
            FlowActionButton(content, "VOLVER A ARENA", muted, () => { arenaCollectionVisible = false; ShowSection(HubSection.Pvp); });
            ApplyArenaGlassStyle(content);
        }

        private void OpenArenaCollectionFamily(int family)
        {
            arenaCollectionFocusFamily = family;
            arenaCollectionVisible = true; ShowSection(HubSection.Pvp);
        }

        private void RefreshArenaLoadoutButton(Button button, int family, int slot)
        {
            var txt = button.GetComponentInChildren<Text>();
            if (txt == null) return;
            var module = ArenaCatalog.Find(family, arenaCandidates[family][slot]);
            txt.text = (slot < ArenaCatalog.ActiveCounts[family] ? "ACTIVO · " : "RESERVA · ") + module.Name + "   ›";
        }

        private void CycleArenaCandidate(int family, int slot)
        {
            string current = arenaCandidates[family][slot]; int index = Array.IndexOf(ArenaIds[family], current);
            for (int step = 1; step <= ArenaIds[family].Length; step++)
            {
                string next = ArenaIds[family][(index + step) % ArenaIds[family].Length];
                if (!ArenaVariantUnlocked(family, next)) continue;
                int existing = Array.IndexOf(arenaCandidates[family], next);
                if (existing >= 0) { arenaCandidates[family][existing] = current; }
                arenaCandidates[family][slot] = next; ShowSection(HubSection.Pvp); return;
            }
        }

        private void CycleArenaBan(int family)
        {
            int index = Array.IndexOf(ArenaIds[family], arenaBans[family]);
            for (int step = 1; step <= ArenaIds[family].Length; step++)
            {
                string next = ArenaIds[family][(index + step) % ArenaIds[family].Length];
                if (!ArenaVariantUnlocked(family, next)) continue;
                arenaBans[family] = next; ShowSection(HubSection.Pvp); return;
            }
        }

        private bool ArenaVariantUnlocked(int family, string id)
        {
            if (family == 0 && Array.IndexOf(new[] { "fast", "heavy", "burst", "piercing" }, id) >= 0) return true;
            if (family == 1 && Array.IndexOf(new[] { "quick", "heavy", "interceptor", "sustained" }, id) >= 0) return true;
            if (family == 2 && Array.IndexOf(new[] { "disrupt", "economy", "production" }, id) >= 0) return true;
            return factoryV2Save != null && HasFactoryV2Research(ArenaCatalog.Families[family] + ":" + id);
        }

        private void StartArenaLocalMatch()
        {
            InitArenaLoadout(); arenaCollectionVisible = false;
            arenaLocalMatch = new ArenaLocalMatch(arenaCandidates, arenaBans);
            arenaLocalMatch.OnMessage = _ => RefreshArenaCombatHud();
            arenaBattleVisible = true; ShowSection(HubSection.Pvp);
        }

        private void BuildArenaCombatScreen()
        {
            var root = Panel("Arena Fullscreen Fight", content, new Color32(5, 20, 34, 245));
            arenaCombatRoot = root.transform;
            float viewportHeight = screenScroll != null && screenScroll.viewport != null ? screenScroll.viewport.rect.height : Screen.height;
            if (viewportHeight <= 0) viewportHeight = Screen.height;
            LayoutElement(root).preferredHeight = Mathf.Max(1, viewportHeight - 38);
            var art = Panel("Arena Fight Art", root.transform, Color.white);
            Anchor(art, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            art.GetComponent<Image>().sprite = Resources.Load<Sprite>("FactoryWarsBattlefield"); art.GetComponent<Image>().preserveAspect = true;
            art.GetComponent<Image>().color = Color.white;
            Panel("Fight glass overlay", art.transform, new Color(5f / 255, 22f / 255, 38f / 255, .25f));
            Anchor(art.transform.Find("Fight glass overlay").gameObject, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            var tintObject = Panel("Arena effect tint", art.transform, new Color(0, 0, 0, 0));
            Anchor(tintObject, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            arenaFightTint = tintObject.GetComponent<Image>();
            arenaFightTint.raycastTarget = false;
            arenaEnemyBarrierVisual = Panel("Enemy barrier glow", art.transform, new Color32(30, 204, 255, 85));
            Anchor(arenaEnemyBarrierVisual, new Vector2(.33f, .55f), new Vector2(.67f, .73f), Vector2.zero, Vector2.zero);
            arenaPlayerBarrierVisual = Panel("Player barrier glow", art.transform, new Color32(30, 204, 255, 85));
            Anchor(arenaPlayerBarrierVisual, new Vector2(.33f, .12f), new Vector2(.67f, .30f), Vector2.zero, Vector2.zero);
            arenaTimeText = PlacedLabel(root.transform, "05:00", 18, white, FontStyle.Bold, TextAnchor.MiddleCenter, new Vector2(.4f, .91f), new Vector2(.6f, 1), Vector2.zero, Vector2.zero);
            arenaResourceText = PlacedLabel(root.transform, "240 C · 100 E · +9 C/s", 10, white, FontStyle.Bold, TextAnchor.MiddleCenter, new Vector2(.18f, .85f), new Vector2(.82f, .92f), Vector2.zero, Vector2.zero);
            arenaPlayerHpText = PlacedLabel(root.transform, "TU NÚCLEO · 1000", 11, white, FontStyle.Bold, TextAnchor.MiddleLeft, new Vector2(.03f, .78f), new Vector2(.48f, .85f), Vector2.zero, Vector2.zero);
            arenaBotHpText = PlacedLabel(root.transform, "RIVAL · 1000", 11, white, FontStyle.Bold, TextAnchor.MiddleRight, new Vector2(.52f, .78f), new Vector2(.97f, .85f), Vector2.zero, Vector2.zero);
            arenaQueueText = PlacedLabel(root.transform, "COLA · 0 / 2", 9, white, FontStyle.Bold, TextAnchor.MiddleCenter, new Vector2(.25f, .72f), new Vector2(.75f, .78f), Vector2.zero, Vector2.zero);
            BuildArenaTap(root.transform, 0, 0, "COHETE IZQUIERDO", new Vector2(.02f, .48f), new Vector2(.29f, .61f));
            BuildArenaTap(root.transform, 0, 1, "COHETE DERECHO", new Vector2(.71f, .48f), new Vector2(.98f, .61f));
            BuildArenaTap(root.transform, 1, 0, "ESCUDO IZQUIERDO", new Vector2(.02f, .31f), new Vector2(.34f, .43f));
            BuildArenaTap(root.transform, 1, 1, "ESCUDO DERECHO", new Vector2(.66f, .31f), new Vector2(.98f, .43f));
            arenaNodeText = PlacedLabel(root.transform, "NODO CENTRAL · NEUTRAL", 10, gold, FontStyle.Bold, TextAnchor.MiddleCenter, new Vector2(.32f, .57f), new Vector2(.68f, .65f), Vector2.zero, Vector2.zero);
            var guardians = FlowActionButton(root.transform, "ENVIAR GUARDIANES · 65 C", gold, () => ArenaQueue("guardians", "Guardianes", () => arenaLocalMatch.Guardians(0)));
            Anchor(guardians.gameObject, new Vector2(.31f, .51f), new Vector2(.69f, .57f), Vector2.zero, Vector2.zero);
            BuildArenaTap(root.transform, 2, 0, "SABOTAJE", new Vector2(.02f, .15f), new Vector2(.48f, .27f));
            var economy = FlowActionButton(root.transform, "MEJORA ECONÓMICA", new Color32(69, 230, 174, 240), () => ArenaQueue("growth", "Mejora económica", () => arenaLocalMatch.Upgrade(0)));
            Anchor(economy.gameObject, new Vector2(.52f, .15f), new Vector2(.98f, .27f), Vector2.zero, Vector2.zero);
            arenaEffectText = PlacedLabel(root.transform, "", 9, cyan, FontStyle.Bold, TextAnchor.MiddleCenter, new Vector2(.1f, .02f), new Vector2(.9f, .14f), Vector2.zero, Vector2.zero);
            var exit = FlowActionButton(root.transform, "SALIR", muted, LeaveArenaFight); Anchor(exit.gameObject, new Vector2(.35f, 0), new Vector2(.65f, .055f), Vector2.zero, Vector2.zero);
            ApplyArenaGlassStyle(root.transform); RefreshArenaCombatHud();
        }

        private void BuildArenaTap(Transform parent, int family, int slot, string label, Vector2 min, Vector2 max)
        {
            var module = ArenaCatalog.Find(family, arenaLocalMatch.Players[0].Active[family][slot]);
            var button = FlowActionButton(parent, label + " · " + module.Name, family == 0 ? new Color32(240, 126, 75, 240) : family == 1 ? cyan : new Color32(179, 120, 250, 240), () => { });
            var gesture = button.gameObject.AddComponent<ArenaLongPressGesture>();
            gesture.Initialize(() => OpenArenaPicker(family, slot), () =>
            {
                var selected = ArenaCatalog.Find(family, arenaLocalMatch.Players[0].Active[family][slot]);
                if (family == 2 && selected.Targeted) OpenArenaTargetPicker(selected);
                else ArenaQueue(family + ":" + selected.Id, selected.Name, () => arenaLocalMatch.Use(0, family, slot));
            });
            button.onClick.RemoveAllListeners(); button.onClick.AddListener(gesture.HandleClick);
            arenaCombatButtons[family, slot] = button;
            Anchor(button.gameObject, min, new Vector2(min.x + (max.x - min.x) * .78f, max.y), Vector2.zero, Vector2.zero);
            var change = FlowActionButton(parent, "↻", cyan, () => OpenArenaPicker(family, slot));
            Anchor(change.gameObject, new Vector2(min.x + (max.x - min.x) * .80f, min.y), max, Vector2.zero, Vector2.zero);
        }

        private void ArenaQueue(string key, string name, Action action)
        { if (arenaLocalMatch != null) { arenaLocalMatch.Queue(key, name, action); RefreshArenaCombatHud(); } }

        private void OpenArenaPicker(int family, int slot)
        {
            if (arenaPicker != null) Destroy(arenaPicker);
            arenaPicker = Panel("Arena module picker", arenaCombatRoot, new Color32(3, 17, 29, 248));
            Anchor(arenaPicker, new Vector2(.08f, .12f), new Vector2(.92f, .88f), Vector2.zero, Vector2.zero);
            PlacedLabel(arenaPicker.transform, "ELEGIR " + ArenaCatalog.Names[family], 15, white, FontStyle.Bold, TextAnchor.MiddleCenter, new Vector2(0, .84f), Vector2.one, Vector2.zero, Vector2.zero);
            int index = 0;
            for (int i = 0; i < arenaLocalMatch.Players[0].Options[family].Length; i++)
            {
                string id = arenaLocalMatch.Players[0].Options[family][i]; if (Array.IndexOf(arenaLocalMatch.Players[0].Active[family], id) >= 0) continue;
                string option = id; var m = ArenaCatalog.Find(family, id);
                var choice = FlowActionButton(arenaPicker.transform, m.Name + " · 40 E", cyan, () =>
                { arenaLocalMatch.Change(0, family, slot, option); Destroy(arenaPicker); arenaPicker = null; RefreshArenaCombatHud(); });
                float top = .78f - index * .13f; Anchor(choice.gameObject, new Vector2(.08f, top - .11f), new Vector2(.92f, top), Vector2.zero, Vector2.zero); index++;
            }
            var close = FlowActionButton(arenaPicker.transform, "CERRAR", muted, () => { Destroy(arenaPicker); arenaPicker = null; });
            Anchor(close.gameObject, new Vector2(.25f, .03f), new Vector2(.75f, .13f), Vector2.zero, Vector2.zero);
        }

        private void OpenArenaTargetPicker(ArenaModule module)
        {
            if (arenaPicker != null) Destroy(arenaPicker);
            arenaPicker = Panel("Arena target picker", arenaCombatRoot, new Color32(3, 17, 29, 248));
            Anchor(arenaPicker, new Vector2(.08f, .18f), new Vector2(.92f, .82f), Vector2.zero, Vector2.zero);
            PlacedLabel(arenaPicker.transform, "OBJETIVO · " + module.Name, 14, white, FontStyle.Bold, TextAnchor.MiddleCenter, new Vector2(0, .84f), Vector2.one, Vector2.zero, Vector2.zero);
            int[] families = module.SlotTargeted ? new[] { 0, 0, 1, 1 } : new[] { 0, 1, 2 };
            int[] slots = module.SlotTargeted ? new[] { 0, 1, 0, 1 } : new[] { 0, 0, 0 };
            for (int i = 0; i < families.Length; i++)
            {
                int targetFamily = families[i], targetSlot = slots[i];
                string targetName = ArenaCatalog.Names[targetFamily] + (module.SlotTargeted ? (targetSlot == 0 ? " · IZQUIERDO" : " · DERECHO") : "");
                var choice = FlowActionButton(arenaPicker.transform, targetName, cyan, () =>
                {
                    ArenaQueue("2:" + module.Id, module.Name, () => arenaLocalMatch.Use(0, 2, 0, targetFamily, targetSlot));
                    Destroy(arenaPicker); arenaPicker = null;
                });
                float top = .76f - i * .15f; Anchor(choice.gameObject, new Vector2(.08f, top - .12f), new Vector2(.92f, top), Vector2.zero, Vector2.zero);
            }
            var close = FlowActionButton(arenaPicker.transform, "CERRAR", muted, () => { Destroy(arenaPicker); arenaPicker = null; });
            Anchor(close.gameObject, new Vector2(.25f, .03f), new Vector2(.75f, .14f), Vector2.zero, Vector2.zero);
        }

        private void RefreshArenaCombatHud()
        {
            if (arenaLocalMatch == null || arenaTimeText == null) return;
            var p = arenaLocalMatch.Players[0]; var e = arenaLocalMatch.Players[1];
            int remaining = Mathf.CeilToInt(300 - arenaLocalMatch.Time);
            arenaTimeText.text = (remaining / 60).ToString("00") + ":" + (remaining % 60).ToString("00");
            arenaResourceText.text = p.Credits.ToString("0") + " C · " + p.Energy.ToString("0") + " E · +" + arenaLocalMatch.Income(0).ToString("0") + " C/s";
            arenaPlayerHpText.text = "TU NÚCLEO · " + p.Hp.ToString("0") + "   ◈ " + p.Shield.ToString("0");
            arenaBotHpText.text = "RIVAL · " + e.Hp.ToString("0") + "   ◈ " + e.Shield.ToString("0");
            if (arenaQueueText != null)
            {
                int queueLimit = arenaLocalMatch.Orders.Count == 3 || (arenaLocalMatch.Orders.Count == 2 && arenaLocalMatch.Orders[0].Key == arenaLocalMatch.Orders[1].Key) ? 3 : 2;
                arenaQueueText.text = "COLA · " + arenaLocalMatch.Orders.Count + " / " + queueLimit + (p.Pending != null ? "   ·   CAMBIO " + Mathf.CeilToInt(p.Pending.Remaining) + "s" : "");
            }
            if (arenaNodeText != null) arenaNodeText.text = arenaLocalMatch.NodeOwner < 0 ? "NODO CENTRAL · NEUTRAL" : arenaLocalMatch.NodeOwner == 0 ? "NODO · TUYO · " + arenaLocalMatch.NodeGuardians + " GUARDIANES" : "NODO · RIVAL · " + arenaLocalMatch.NodeGuardians + " GUARDIANES";
            for (int family = 0; family < 3; family++) for (int slot = 0; slot < ArenaCatalog.ActiveCounts[family]; slot++)
            {
                var button = arenaCombatButtons[family, slot]; if (button == null) continue;
                var module = ArenaCatalog.Find(family, p.Active[family][slot]); var label = button.GetComponentInChildren<Text>();
                if (label != null) label.text = (family == 0 ? (slot == 0 ? "COHETE IZQUIERDO · " : "COHETE DERECHO · ") : family == 1 ? (slot == 0 ? "ESCUDO IZQUIERDO · " : "ESCUDO DERECHO · ") : "SABOTAJE · ") + module.Name;
            }
            if (arenaEffectText != null) arenaEffectText.text = arenaLocalMatch.Status;
            SyncArenaFlightMarkers();
            UpdateArenaBarrierVisual(arenaPlayerBarrierVisual, p);
            UpdateArenaBarrierVisual(arenaEnemyBarrierVisual, e);
            if (arenaFightTint != null)
            {
                float pulse = Mathf.Max(arenaLocalMatch.SabotagePulse, Mathf.Max(arenaLocalMatch.GrowthPulse, arenaLocalMatch.NodePulse));
                Color tint = arenaLocalMatch.SabotagePulse > 0 ? ArenaSabotageColor(arenaLocalMatch.LastSabotageId) : arenaLocalMatch.GrowthPulse > 0 ? new Color(.15f, 1f, .5f, .12f) : new Color(1f, .7f, .12f, .12f);
                tint.a *= pulse > 0 ? Mathf.Clamp01(pulse) : 0; arenaFightTint.color = tint;
            }
            UpdateArenaFightHeight();
        }

        private void UpdateArenaFightHeight()
        {
            if (arenaCombatRoot == null || screenScroll == null || screenScroll.viewport == null) return;
            float height = screenScroll.viewport.rect.height;
            if (height <= 0 || Mathf.Abs(height - arenaFightViewportHeight) < 1) return;
            arenaFightViewportHeight = height;
            LayoutElement(arenaCombatRoot.gameObject).preferredHeight = Mathf.Max(1, height - 38);
            LayoutRebuilder.MarkLayoutForRebuild(content);
        }

        private static Color ArenaSabotageColor(string id)
        {
            switch (id)
            {
                case "economy": return new Color(.95f, .28f, .35f, .15f);
                case "production": return new Color(1f, .56f, .16f, .15f);
                case "cooldown": return new Color(.54f, .34f, 1f, .15f);
                case "launch": return new Color(1f, .3f, .19f, .15f);
                case "ambush": return new Color(.22f, .5f, 1f, .15f);
                case "friction": return new Color(.94f, .72f, .19f, .15f);
                case "supplies": return new Color(.22f, .84f, .6f, .15f);
                case "reconfigure": return new Color(.9f, .26f, .72f, .15f);
                case "precision": return new Color(.24f, .72f, 1f, .15f);
                default: return new Color(.65f, .25f, .9f, .14f);
            }
        }

        private void SyncArenaFlightMarkers()
        {
            int count = arenaLocalMatch.Flights.Count;
            while (arenaFlightMarkers.Count < count)
            {
                var marker = Panel("Arena flying effect", arenaCombatRoot, new Color32(255, 191, 87, 255));
                marker.GetComponent<Image>().raycastTarget = false;
                arenaFlightMarkers.Add(marker);
            }
            while (arenaFlightMarkers.Count > count)
            {
                int last = arenaFlightMarkers.Count - 1; Destroy(arenaFlightMarkers[last]); arenaFlightMarkers.RemoveAt(last);
            }
            for (int i = 0; i < count; i++)
            {
                var flight = arenaLocalMatch.Flights[i]; var marker = arenaFlightMarkers[i]; var rect = marker.GetComponent<RectTransform>();
                float span = Mathf.Max(.1f, flight.At - flight.Started); float progress = Mathf.Clamp01((arenaLocalMatch.Time - flight.Started) / span);
                float x = flight.Kind == "guardians" ? .5f : flight.Slot == 0 ? .34f : .66f;
                float y;
                if (flight.Kind == "guardians") y = flight.Side == 0 ? Mathf.Lerp(.18f, .5f, progress) : Mathf.Lerp(.79f, .5f, progress);
                else if (flight.Kind == "shield") y = flight.Side == 0 ? Mathf.Lerp(.40f, .25f, progress) : Mathf.Lerp(.58f, .74f, progress);
                else y = flight.Side == 0 ? Mathf.Lerp(.18f, .79f, progress) : Mathf.Lerp(.79f, .18f, progress);
                rect.anchorMin = rect.anchorMax = new Vector2(x, y); rect.anchoredPosition = Vector2.zero; rect.sizeDelta = new Vector2(flight.Kind == "rocket" ? 20 : 14, flight.Kind == "rocket" ? 20 : 14);
                var color = ArenaFlightColor(flight);
                if (flight.Kind == "rocket" && flight.Module != null && flight.Module.Shots > 1) rect.sizeDelta = new Vector2(25, 25);
                marker.GetComponent<Image>().color = color;
            }
        }

        private static Color ArenaFlightColor(ArenaLocalMatch.Flight flight)
        {
            string id = flight.Module == null ? "" : flight.Module.Id;
            if (flight.Kind == "guardians") return new Color32(252, 216, 110, 255);
            if (flight.Kind == "shield")
            {
                switch (id)
                {
                    case "interceptor": case "antiburst": case "antipiercing": return new Color32(182, 145, 255, 255);
                    case "regenerative": return new Color32(87, 249, 156, 255);
                    case "reflection": return new Color32(255, 118, 214, 255);
                    case "reinforced": case "heavy": return new Color32(71, 165, 255, 255);
                    case "emergency": return new Color32(255, 218, 83, 255);
                    default: return new Color32(71, 223, 255, 255);
                }
            }
            switch (id)
            {
                case "heavy": return new Color32(255, 71, 61, 255);
                case "burst": return new Color32(255, 202, 74, 255);
                case "piercing": return new Color32(203, 110, 255, 255);
                case "emp": return new Color32(79, 218, 255, 255);
                case "breaker": return new Color32(255, 107, 86, 255);
                case "vector": return new Color32(141, 245, 111, 255);
                case "exposed": return new Color32(255, 137, 61, 255);
                default: return flight.Side == 0 ? new Color32(255, 164, 86, 255) : new Color32(255, 91, 92, 255);
            }
        }

        private void UpdateArenaBarrierVisual(GameObject visual, ArenaLocalMatch.Player player)
        {
            if (visual == null) return;
            if (player.Barriers.Count == 0) { visual.SetActive(false); return; }
            visual.SetActive(true);
            var barrier = player.Barriers[player.Barriers.Count - 1];
            Color tint = ArenaFlightColor(new ArenaLocalMatch.Flight { Kind = "shield", Module = barrier.Module });
            tint.a = .12f + Mathf.Sin(Time.unscaledTime * 4f) * .035f;
            visual.GetComponent<Image>().color = tint;
        }

        private void LeaveArenaFight()
        {
            if (arenaPicker != null) Destroy(arenaPicker);
            arenaPicker = null; arenaCombatRoot = null; arenaLocalMatch = null; arenaBattleVisible = false;
            arenaFlightMarkers.Clear(); arenaPlayerBarrierVisual = null; arenaEnemyBarrierVisual = null; arenaFightTint = null; arenaFightViewportHeight = 0;
            for (int family = 0; family < 3; family++) for (int slot = 0; slot < 2; slot++) arenaCombatButtons[family, slot] = null;
            ShowSection(HubSection.Pvp);
        }

    }

    internal sealed class ArenaLongPressGesture : MonoBehaviour, UnityEngine.EventSystems.IPointerDownHandler,
        UnityEngine.EventSystems.IPointerUpHandler, UnityEngine.EventSystems.IPointerExitHandler
    {
        private Action openPicker, tapAction;
        private float downAt;
        private bool isDown, fired, suppressClick;
        public void Initialize(Action picker, Action tap) { openPicker = picker; tapAction = tap; }
        public void OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData)
        { isDown = true; fired = false; suppressClick = false; downAt = Time.unscaledTime; }
        public void OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData)
        { isDown = false; }
        public void OnPointerExit(UnityEngine.EventSystems.PointerEventData eventData) { isDown = false; }
        private void Update()
        {
            if (isDown && !fired && Time.unscaledTime - downAt >= 3f)
            { fired = true; suppressClick = true; openPicker?.Invoke(); }
        }
        public void HandleClick()
        { if (suppressClick) { suppressClick = false; return; } tapAction?.Invoke(); }
    }
}
