# Arquitectura y guía para desarrolladores

Factory Wars mantiene como experiencia web activa la Megafábrica v2 y Arena v2: una práctica local conectada por investigaciones permanentes. La web V1 está archivada en `archive/v1/public/`; el runtime del servidor todavía puede cargar sus reglas para compatibilidad. El estado del archivo y sus límites están en [ARCHIVE_V1.md](ARCHIVE_V1.md).

## Primer recorrido por el código

El mapa visual del flujo del jugador y sus dependencias está en [GAME_FLOW.md](GAME_FLOW.md).

1. Abrí `public/index.html`: permite elegir Megafábrica v2 o Arena v2.
2. `public/game/adapters/web/factory-v2-controller.js` coordina producción, proyectos, contratos, misiones y prestigio.
3. `public/game/domain/factory-v2/` contiene catálogo, economía incremental, progresión y formato de guardado local.
4. `public/game/adapters/web/arena-v2-controller.js` conecta la preparación, los bloqueos, los bonus y el combate local.
5. `public/game/domain/arena-v2/` contiene el motor y balance de Arena v2; `public/game/application/arena-v2-bot.js` implementa el rival de práctica.
6. Las investigaciones V2 se comparten mediante el guardado local del mismo origen del navegador.
7. El runtime online clásico sigue aislado en `server/src/game/arena-runtime.js` y lee sus reglas V1 desde `archive/v1/public/`.

La aplicación activa V2 usa módulos ES en sus dos controladores. El orden clásico de los scripts de Arena V1 se conserva dentro de `archive/v1/public/arena.html`; el servidor V1 sigue cargando esas mismas capas desde allí.

## Estructura activa

```text
public/
  index.html                         Selector de Megafábrica v2 y Arena v2
  factory-v2.html                    Práctica incremental local
  arena-v2.html                      Práctica local contra bot
  game/
    domain/
      arena-v2/                      Reglas y balance del combate V2
      factory-v2/                    Catálogo, progreso y guardado de fábrica V2
    application/
      arena-v2-bot.js                Rival de práctica reproducible
    ports/                           Próxima extracción: contratos de servicios
    adapters/
      web/                           Controladores, runtime y puente de navegador
      persistence/                   Integraciones históricas; no usadas por V2
      platform/                      Punto futuro para SDKs nativos
    presentation/
      styles/                        CSS por pantalla
      screens/                       Punto futuro para vistas separadas
      components/                    Punto futuro para componentes reutilizables
    platforms/
      web/ mobile/ desktop/ server/  Puntos de composición por plataforma
    shared/                          Código compartido que no es regla de juego
archive/v1/public/                   Aplicación web V1; fuera de lo publicado por Pages
legacy/v1.6/                         Snapshot histórico anterior
docs/                                Diseño, operaciones y guía de arquitectura
analytics/                           Simulación y reportes de balance
supabase/                            Esquema, vistas, RPC y migraciones
tests/                               Lugar para pruebas automatizadas futuras
```

Las páginas activas V2 están en la raíz de `public/`. La PWA usa rutas relativas para funcionar bajo el prefijo de GitHub Pages. El archivo V1 queda fuera de `public/`, aunque sus reglas siguen incluidas en el servidor para compatibilidad. Unity es un cliente separado y este corte no modifica su integración.

## Dependencias objetivo

```text
platforms (web / mobile / desktop / server)
        ↓
presentation (screens, input, rendering)
        ↓
application (use cases, match/league sessions)
        ↓
domain (rules, state, simulation, balance data)
        ↑
ports (clock, random, storage, identity, network)
        ↑
adapters (browser, local save, Supabase, native SDKs)
```

Las dependencias deben apuntar hacia el dominio. El dominio no debe importar el DOM, `localStorage`, Supabase, Three.js ni SDKs de tiendas. La aplicación coordina casos de uso a través de interfaces; cada plataforma conecta esas interfaces con sus servicios concretos.

## Límites actuales de V2

- `factory-v2-controller.js` sigue coordinando DOM, `localStorage` y el reloj de navegador; las reglas del ciclo están en `factory-v2/factory-engine.js`.
- Arena V2 se ejecuta localmente contra un bot; no conecta cuentas, Liga, partidas online ni recompensas.
- El estado V2 se guarda únicamente en el navegador. La integración con Unity no se cambió ni se considera conectada a estos motores.
- El servidor online conserva las reglas V1 como compatibilidad; la interfaz V1 archivada no forma parte de los archivos públicos de Pages.
- No hay un build TypeScript ni una publicación móvil nativa.

## Contratos que deben guiar el diseño

- **Reglas deterministas:** simulación y bots reciben una semilla explícita; mismos ajustes y semilla deben dar mismo resultado. No usar `Math.random()` dentro de reglas migradas.
- **Tiempo inyectado:** progreso idle y relojes de partida deben depender de un reloj proporcionado, no de llamadas directas a `Date.now()` en el dominio.
- **Estado versionado:** el formato persistido tiene versión y se transforma en el borde del adaptador. Las reglas trabajan con estado válido, no con JSON sin validar.
- **Comandos de aplicación:** la UI pide acciones como `startMatch`, `submitArenaAction`, `resolveLeagueRound`, `upgradeBuilding` y `prestigeEmpire`; no recalcula costos en el renderizado.
- **Autoridad online:** resultados enviados por un cliente no son confiables para premios. Ranked, Liga compartida y recompensas deben validarse o simularse en servidor.
- **Balance separado:** extraer reglas conserva los valores existentes. Ajustes de balance deben ser cambios distintos y citar la simulación usada.
- **Compatibilidad de saves:** cada cambio de formato conserva una migración desde las claves actuales de `localStorage` y los registros Supabase.

Para el procedimiento de creación de archivos, dependencias y revisión de cambios, seguir `docs/FILE_CONVENTIONS.md`. Para el orden de migración y criterios de paridad, ver `docs/MIGRATION_PLAN.md`.


El plan de migración a Android e iOS está en [sprints de migración móvil](sprint/SPRINTS_MIGRACION_MOBILE.md); la tarea y sus criterios de aceptación están en [TAREA_MIGRACION_MOBILE.md](tarea/TAREA_MIGRACION_MOBILE.md).
