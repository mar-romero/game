# Cómo se desarrolla Factory Wars

Este mapa muestra el recorrido del jugador y cómo se conectan las partes activas del código. La vista de red es una metáfora para explicar las dependencias y los ciclos de progreso; el juego no usa una red neuronal para decidir las reglas.

## Recorrido de una sesión

```mermaid
flowchart TD
    A[Jugador abre public/index.html] --> B{Elegir práctica}
    B -->|Megafábrica| C[factory-v2.html]
    C --> D[Producir recursos y mejorar máquinas]
    D --> E[Elegir proyecto, contratos y misiones]
    E --> F{Completar misiones y prestigiar}
    F -->|Sí| G[Elegir investigación PvP permanente]
    G --> H[Reiniciar el ciclo de fábrica]
    H --> D
    F -->|Todavía no| D
    B -->|Arena| I[arena-v2.html]
    I --> J[Leer investigaciones V2 locales]
    J --> K[Elegir bonus, arsenal y bloqueos]
    K --> L[Jugar contra bot y gastar Créditos/Energía]
    L --> M[Ver resultado local; no hay premios]
    G -. mismo navegador y origen .-> J
```

## Red de dependencias

Las flechas muestran qué componente aporta datos o decisiones al siguiente. Las investigaciones permanentes pasan de Megafábrica a la preparación de Arena en el mismo navegador.

```mermaid
flowchart LR
    subgraph Presentación
      WEB[Web / HTML]
      UI[Controladores y runtime]
      CSS[Estilos]
      WEB --> UI
      CSS --> WEB
    end

    subgraph Aplicación y dominio V2
      FC[Factory Engine<br/>producción y ciclos]
      FA[Arena Practice Bot]
      FM[Factory V2 Catalog + Save]
      AM[Arena V2 Match Engine]
      FM --> FC
      FC --> FM
      FA --> AM
    end

    subgraph Adaptadores
      LOCAL[Estado local]
      PLATFORM[Otros clientes<br/>Unity / futuros]
    end

    UI --> FC
    UI --> AM
    UI --> LOCAL
    LOCAL --> UI
    AM --> UI
    FC --> LOCAL
    FM --> AM
    PLATFORM -. sin integración V2 asumida .-> FC
    AM -. práctica sin premios .-> UI
```

## Decisiones principales del jugador

| Decisión | Condición | Efecto |
| --- | --- | --- |
| Construir edificio | Recursos suficientes | Aumenta capacidad y producción persistente. |
| Investigar | Intel, requisitos y cupo disponibles | Desbloquea tecnologías para Imperio o Arena. |
| Completar contrato | Reunir los recursos solicitados | Convierte suministros en créditos, intel y progreso. |
| Entrar en Arena | Preparar arsenal, bloqueos y bonus | Inicia una práctica local contra un bot; no hay premios ni Liga. |
| Elegir acción de combate | Recursos y reglas de partida lo permiten | Cambia economía, defensa, ataque o control del nodo. |
| Subir de prestigio | Completar las metas del ciclo | Reinicia parte del progreso y conserva beneficios de legado. |

## Cómo leerlo para desarrollar

1. Para cambiar una regla de Megafábrica v2, empezar por `public/game/domain/factory-v2/`.
2. Para cambiar una regla de Arena v2, empezar por `public/game/domain/arena-v2/`.
3. Para cambiar interacción o presentación web, revisar los controladores V2 y `public/game/presentation/styles/`.
4. Los guardados V2 son locales y no se sincronizan con Supabase.
5. La V1 archivada sigue en `archive/v1/public/`; el motor del servidor la carga desde esa ruta.

Algunas reglas de Arena y flujos de Imperio todavía viven en controladores/extensiones históricos. La arquitectura objetivo y ese trabajo pendiente están descritos en [ARCHITECTURE.md](ARCHITECTURE.md) y [MIGRATION_PLAN.md](MIGRATION_PLAN.md).

Para ver el ida y vuelta detallado entre Megafábrica, PvP y civilizaciones, abrir [FACTORY_PVP_CIVILIZATIONS.md](FACTORY_PVP_CIVILIZATIONS.md).
