# Factory Wars — Megafábrica V3 (prototipo funcional)

Versión de trabajo para probar el sistema industrial, no versión comercial terminada.

## Cambios de juego

- Proyectos con bonus parciales al 25 / 60 / 100% de aportes (el bonus máximo se mantiene).
- Cuatro prioridades económicas y espera de 60 segundos entre cambios.
- Cinco contratos (tres originales + dos especiales); serie de tres tipos diferentes recompensa una vez por ciclo.
- Cuatro rutas industriales seleccionables para los nuevos ciclos, con misiones diferentes.
- Escalado de costos por prestigio de +20% compuesto y producción industrial por prestigio +25% compuesto. También se aceleran suavemente los contratos con piso de 15s; pendiente balance real.
- Los ciclos posteriores a las 28 investigaciones PvP siguen otorgando progreso industrial, sin aumentar poder PvP.

## Lo que NO se modificó

- No se cambió `public/index.html` ni su vieja lógica de Imperio/Megafábrica.
- No se cambiaron las reglas, armas, estadísticas ni el servidor de Arena V2.
- No se incorporaron edificios en un mapa físico, fondos, animaciones, gráficos ni Capacitor.
- No se cambió Supabase ni se desplegó código en producción.

## Riesgos / datos a medir

1. Se requiere validar que distintas rutas y modos sean útiles y no exista una estrategia única dominante.
2. Dos curvas compuestas requieren especial atención en ciclos altos (1.2 para costos y 1.25 para producción).
3. La limitación de 4 horas offline se conservó: evaluar con telemetría si molesta a usuarios móviles.
4. El avance de proyectos usa la suma proporcional de materiales entregados. La estrategia de entregar primero el recurso abundante puede activar bonus temprano; observar si es interesante o explotable.
5. El motor nuevo y su controlador son una práctica local: las experiencias del juego principal siguen usando las reglas anteriores.
6. La selección de investigaciones para Arena depende de jugar ambas páginas en el mismo navegador y origen.

## Verificación

`node --experimental-default-type=module tests/factory-v3.test.mjs` valida creación, migración V1, proyectos, modos, contratos, prestigio, aislamiento de desbloqueos y 12 ciclos sucesivos mediante comandos reales. Es una prueba funcional, no un balanceo competitivo.

Para reglas y compatibilidad de save: [`public/game/domain/factory-v2/README.md`](../public/game/domain/factory-v2/README.md).
