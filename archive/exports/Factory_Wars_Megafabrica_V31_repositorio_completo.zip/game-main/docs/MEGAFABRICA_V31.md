# Factory Wars — Megafábrica V3.1: ajuste de progresión industrial

## Alcance

Esta actualización **modifica la implementación modular** accesible en `public/factory-v2.html`, y los módulos compartidos en `public/game/domain/factory-v2/`. **No altera** `public/index.html` (Megafábrica histórica), Arena V2, servidor, Unity, Supabase ni los contenidos de los desbloqueos PvP.

### Motivo

Las simulaciones de V3 mostraron que producción `1.25^prestigios` frente a requisitos `1.2^prestigios` causaba progresión demasiado acelerada. En el prestigio 28 la productividad alcanzaba ×516,99 frente a costos ×164,84. Los contratos descendían a 15 segundos. Era posible completar el progreso PvP en aproximadamente 117–165 minutos simulados con bots de compras eficientes, y algunos ciclos posteriores bajaban a pocos segundos.

## Decisiones implementadas

| Cambio | V3 | V3.1 |
|---|---|---|
| Costos de mejora, contrato y proyecto | `1.2^p` | Se conserva |
| Producción y recompensas | `1.25^p` | `1.2^p * (1 + 0.35 * (1 - exp(-p/12)))` |
| Ventaja relativa de productividad frente a requisitos | `~3.14×` en p=28 y continúa creciendo | `~1.32×` en p=28, con máximo asintótico `1.35×` |
| Duración de nuevo contrato | `max(15, ceil(base / 1.1^p))` | `max(30, ceil(base * factorRuta / (1 + 0.045*p)))` |
| Ruta logística | Cuatro contratos | Se conservan; −20% tiempo de contrato y +15% recompensa mientras esté elegida |
| Ruta científica | Dos contratos y Centro científico | Se conservan; +30% producción de Intel en el ciclo |
| Ruta proyecto prioritario | Dos mejoras, contrato especial y proyecto | Se conserva; +25% Acero y +15% Energía en el ciclo |
| Ruta industrial | Cuatro mejoras, un contrato y proyecto | Sin bonificación adicional, ya rápida en las políticas ensayadas |

`p` es el **número de prestigios completados**, comenzando en cero. La ventaja sobre costos crece rápido al principio y se estabiliza; **no equivale a subir un 35% cada ciclo**.

Las rutas mantienen la recompensa de **una investigación PvP por prestigio** hasta desbloquear las 28; las rutas no cambian salud, ataques ni energía de Arena. Después de las investigaciones se puede seguir prestigiando hasta 100 ciclos.

## Medidas de prueba, no predicciones de jugadores

Con `node --experimental-default-type=module tests/measure-factory-v31.mjs resultados-v31`, intervalos de decisión automatizada de cinco segundos, producción continua, pago de materiales y rutas repetidas:

| Política de bot | V3, 28 prestigios | V3.1, 28 prestigios |
|---|---:|---:|
| Industrial | ~117 min | ~165 min |
| Logística | ~144 min | ~199 min |
| Mixta | ~154 min | ~211 min |
| Científica, contratos científicos | ~164 min | ~241 min |
| Prioritaria | ~165 min | ~196 min |

Si la política científica usa contratos urgentes, resulta ~171 minutos en V3.1. Esto demuestra que **la elección de contratos importa**: los números no son un ranking definitivo de rutas ni el tiempo de juego humano. Los bots intervienen en intervalos regulares, sin error humano.

Una prueba separada completó **100 ciclos consecutivos**, alternando las cuatro rutas sin añadir recursos, y exportó equipamientos válidos hacia Arena V2. Se ejecutaron **216 partidas bot contra bot** con diferentes niveles de desbloqueo, sin excepciones en esa batería. Son pruebas de lógica, no de experiencia visual o diversión.

## Guardado y retrocompatibilidad

- Se preserva la clave `factory-wars.factory-v2.local.v1` y el formato `schemaVersion: 2`. No se solicita resetear ni migrar un guardado V3 existente.
- No se pierden investigaciones, niveles, recursos, contratos o proyectos existentes. Los contratos que **ya comenzaron** conservan su `endsAt`; los iniciados después del cambio usan las nuevas duraciones.
- Los recursos previamente almacenados no se reducen. El nuevo factor de producción se aplica al **tiempo futuro**.
- La versión V2 original con `schemaVersion: 1` continúa migrando con el backup ya implementado en V3, si aún no se migró.
- El instalador protege el código y se niega a pisar archivos distintos de la versión V3 entregada. Antes de actualizar recomendamos descargar un JSON de guardado desde la pantalla.
- Si vuelves al código V3, el mismo esquema de guardado es legible, pero volverán las fórmulas antiguas; no lo hagas con dos pestañas simultáneas abiertas.

## Ejecutar

Desde la raíz `game-main`:

```bash
node --experimental-default-type=module tests/factory-v3.test.mjs
node --experimental-default-type=module tests/full-flow-stress.mjs --seeds 1 --factory-cycles 100 --out reporte-v31.json
node --experimental-default-type=module tests/measure-factory-v31.mjs resultados-v31
python serve.py
```

Abrir `http://localhost:8000/factory-v2.html`. Se mantuvo el nombre de la pantalla por compatibilidad de vínculos.

## Próxima validación pendiente

No hay prueba visual móvil automática ni datos de retención reales. Hacer un playtest con jugadores no expertos: comprensión de las cuatro rutas, tiempo hasta primer prestigio, satisfacción al volver y cuántas decisiones de producción consideran significativas. Si alguna ruta vuelve a dominar, ajustar sus bonos **después** de comparar jugadores/agentes con políticas de calidad comparable.
