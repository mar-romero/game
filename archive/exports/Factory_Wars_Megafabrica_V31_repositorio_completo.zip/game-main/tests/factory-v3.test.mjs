import assert from 'node:assert/strict';
import {
  createFactory, advanceFactory, executeCommand, productionRates, projectMultiplier,
  projectProgress, projectCost, contractCost, contractReward, contractDuration,
  missions, canPrestige, availableResearch, exportUnlocks, efficiencyMultiplier, costMultiplier
} from '../public/game/domain/factory-v2/factory-engine.js';
import { decodeSave, encodeSave, validateState } from '../public/game/domain/factory-v2/save-format.js';
import { PROJECTS, CONTRACTS, RESEARCH, PRESTIGE_ROUTES, SAVE_KEY } from '../public/game/domain/factory-v2/catalog.js';

function test(name, fn) { try { fn(); console.log(`OK ${name}`); } catch (err) { console.error(`FAIL ${name}`); throw err; } }
const act = (state, command, now = state.savedAt) => executeCommand(state, command, now).state;
const fund = (state, n = 1000000) => {
  const next = structuredClone(state);
  for (const key of Object.keys(next.cycle.resources)) next.cycle.resources[key] = n;
  return validateState(next);
};
const oldFactory = () => ({
  schemaVersion: 1, savedAt: 100000, permanent: { prestigeCount: 0, research: [] },
  cycle: { resources: { credits: 350, energy: 100, steel: 100, intel: 20 },
    buildings: { automation: 1, generator: 1, refinery: 1, lab: 1 },
    upgrades: 0, contractsCompleted: 0, contract: null, project: null }
});

test('V2 compatible key and V3 roundtrip', () => {
  assert.equal(SAVE_KEY, 'factory-wars.factory-v2.local.v1');
  const s = createFactory(1000);
  assert.equal(s.schemaVersion, 2);
  assert.deepEqual(decodeSave(encodeSave(s)), s);
});
test('V2 migration preserves projects, contracts, permanent research, and time', () => {
  const legacy = oldFactory(); legacy.permanent.prestigeCount = 1;
  legacy.permanent.research = [Object.keys(RESEARCH)[0]];
  legacy.cycle.project = { id: 'reactor', delivered: { credits: 450, energy: 350, steel: 450, intel: 60 }, completed: true };
  legacy.cycle.contract = { id: 'urgent', startedAt: 90000, endsAt: 135000 };
  const restored = decodeSave(JSON.stringify(legacy));
  assert.equal(restored.cycle.route, 'legacy');
  assert.equal(restored.cycle.project.completed, true);
  assert.deepEqual(restored.cycle.project.delivered, projectCost(restored, 'reactor'));
  assert.equal(restored.cycle.contract.endsAt, 135000);
  assert.equal(restored.permanent.prestigeCount, 1);
  assert.deepEqual(exportUnlocks(restored).rockets.includes(RESEARCH[legacy.permanent.research[0]].id), true);
  assert.equal(advanceFactory(restored, 136000).cycle.contractsCompleted, 1);
});
test('V2 invalid state is rejected before migrating', () => {
  const legacy = oldFactory(); legacy.cycle.buildings.refinery = 60;
  assert.throws(() => decodeSave(JSON.stringify(legacy)), /V2 inválido/);
  assert.throws(() => decodeSave('{bad'), /JSON corrupto/);
});
test('route selection is required once; new paths differ', () => {
  const s = createFactory(0);
  assert.equal(canPrestige(s), false);
  assert.throws(() => act(s, { type: 'upgrade', id: 'automation' }), /ruta/);
  for (const [id, route] of Object.entries(PRESTIGE_ROUTES)) {
    if (id === 'legacy') continue;
    const chosen = act(s, { type: 'chooseRoute', id });
    assert.equal(missions(chosen)[0].target, route.upgrades);
    assert.throws(() => act(chosen, { type: 'chooseRoute', id }), /ya está/);
  }
});
test('modes change rates and enforce cooldown, even after offline time', () => {
  const s = createFactory(0);
  const science = act(s, { type: 'setMode', id: 'science' }, 0);
  assert.equal(productionRates(science).intel, 0.375);
  assert.equal(productionRates(science).credits, 1.7);
  assert.throws(() => act(science, { type: 'setMode', id: 'heavy' }, 1000), /60 segundos/);
  const heavy = act(science, { type: 'setMode', id: 'heavy' }, 60000);
  assert.equal(productionRates(heavy).steel, 1.2);
  assert.equal(productionRates(heavy).energy, 1.35);
  const next = advanceFactory(heavy, 60000 + 5 * 3600 * 1000);
  assert.equal(next.cycle.resources.steel - heavy.cycle.resources.steel, 1.2 * 14400);
});
test('project reaches partial bonuses at 25%, 60%, and 100%', () => {
  let s = act(fund(createFactory(0)), { type: 'chooseRoute', id: 'industrial' });
  s = act(s, { type: 'selectProject', id: 'reactor' });
  assert.equal(projectMultiplier(s), 1);
  // Deliberate partial state: the engine validates delivered resource bounds.
  s.cycle.project.delivered = { credits: 200, energy: 100, steel: 100, intel: 0 }; // >25% total
  validateState(s); assert.equal(projectMultiplier(s), 1.1);
  s.cycle.project.delivered = { credits: 450, energy: 300, steel: 100, intel: 0 }; // >60%
  validateState(s); assert.equal(projectMultiplier(s), 1.25);
  s = act(s, { type: 'deliverProject' });
  assert.equal(s.cycle.project.completed, true);
  assert.equal(projectProgress(s), 1);
  assert.equal(projectMultiplier(s), 1.5);
});
test('contracts new/old, completion, series reward, routes specials', () => {
  let s = act(fund(createFactory(0)), { type: 'chooseRoute', id: 'priority' });
  for (const id of ['urgent', 'regular', 'freight']) {
    const started = act(s, { type: 'startContract', id });
    assert.equal(started.cycle.contract.id, id);
    s = advanceFactory(started, started.cycle.contract.endsAt);
  }
  assert.equal(s.cycle.contractsCompleted, 3);
  assert.equal(s.cycle.specialContractsCompleted, 1);
  assert.equal(s.cycle.seriesCompleted, true);
  assert.equal(s.cycle.contractTypes.length, 3);
  assert.equal(missions(s).at(-1).progress, 1);
  assert.ok(s.cycle.resources.credits > 0);
  assert.equal(contractDuration(s, 'prototype'), 180);
});
test('prestige raises requirements by 20%, gives bounded industrial advantage, preserves unlocks', () => {
  let s = act(fund(createFactory(0)), { type: 'chooseRoute', id: 'logistics' });
  s.cycle.upgrades = 1; s.cycle.buildings.automation = 2;
  s.cycle.contractsCompleted = 4;
  s.cycle.project = { id:'drones', delivered: projectCost(s, 'drones'), completed: true };
  validateState(s); assert.equal(canPrestige(s), true);
  const next = act(s, { type: 'prestige', research: availableResearch(s)[0][0] });
  assert.equal(next.permanent.prestigeCount, 1);
  assert.equal(next.cycle.route, null);
  assert.ok(efficiencyMultiplier(next) > costMultiplier(next));
  assert.ok(efficiencyMultiplier(next) < 1.25);
  assert.equal(productionRates(next).credits, 2 * efficiencyMultiplier(next));
  assert.equal(projectCost(next, 'reactor').credits, 540);
  assert.equal(contractCost(next, 'urgent').steel, 72);
  assert.equal(contractReward(next, 'urgent').credits, Math.ceil(110 * efficiencyMultiplier(next)));
  assert.equal(contractDuration(next, 'urgent'), 44);
  assert.equal(Object.values(exportUnlocks(next)).flat().length, 13);
});
test('prestige continues industrially after PvP research exhausts', () => {
  const s = createFactory(0);
  s.permanent.research = Object.keys(RESEARCH);
  s.permanent.prestigeCount = s.permanent.research.length;
  s.cycle.route = 'industrial';
  s.cycle.buildings.automation = 5; s.cycle.upgrades = 4;
  s.cycle.contractsCompleted = 1;
  s.cycle.project = { id: 'archive', delivered: projectCost(s, 'archive'), completed: true };
  validateState(s); assert.equal(canPrestige(s), true);
  const after = act(s, { type: 'prestige', research: null });
  assert.equal(after.permanent.prestigeCount, s.permanent.prestigeCount + 1);
  assert.equal(after.permanent.research.length, s.permanent.research.length);
  assert.equal(availableResearch(after).length, 0);
});
test('negative commands and invalid saves rejected', () => {
  const s = createFactory(0);
  assert.throws(() => act(s, {type:'chooseRoute',id:'legacy'}), /desconocida/);
  assert.throws(() => act(s, {type:'setMode',id:'unknown'}), /desconocido/);
  const bad = structuredClone(s); bad.cycle.resources.intel = Infinity;
  assert.throws(() => encodeSave(bad), /Recursos/);
});
console.log('Pruebas de compatibilidad Megafábrica V3.1 completadas');

// Real engine commands, no free-resource injection: verify several consecutive
// cycles can be completed with different routes and growing requirements.
test('12 consecutive prestige cycles remain playable in accelerated simulation', () => {
  const routes = ['industrial', 'logistics', 'scientific', 'priority'];
  let s = createFactory(0), now = 0;
  for (let cycle = 0; cycle < 12; cycle++) {
    const route = routes[cycle % routes.length];
    s = act(s, { type: 'chooseRoute', id: route }, now);
    const projectId = route === 'scientific' ? 'archive' : cycle % 2 ? 'drones' : 'reactor';
    s = act(s, { type: 'selectProject', id: projectId }, now);
    let steps = 0;
    while (!canPrestige(s) && steps++ < 3000) {
      const due = missions(s).find(m => m.progress < m.target);
      let command = null;
      if (due.name.includes('Mejorar')) command = { type:'upgrade', id:'automation' };
      else if (due.name.includes('contratos') || due.name.includes('contrato especial')) {
        if (!s.cycle.contract) command = { type:'startContract', id:route === 'priority' ? 'freight' : 'urgent' };
      } else if (due.name.includes('Terminar')) command = { type:'deliverProject' };
      if (command) {
        try { s = act(s, command, now); continue; }
        catch (error) {
          assert.match(error.message, /Faltan recursos|no tenés materiales/);
        }
      }
      now += 10000;
      s = advanceFactory(s, now);
    }
    assert.equal(canPrestige(s), true, `cycle ${cycle + 1} blocked`);
    s = act(s, { type:'prestige', research:availableResearch(s)[0]?.[0] ?? null }, now);
  }
  assert.equal(s.permanent.prestigeCount, 12);
  assert.ok(now < 12 * 12 * 60 * 1000, 'the first twelve cycles should be feasible in test economy');
});
console.log('Simulación multicíclo completada');

// Regression checks for balancing V3.1 (saves retain schemaVersion 2).
test('bounded permanent advantage stays useful without 25% exponential runaway', () => {
  const s = createFactory(0);
  let last = 0;
  for (const p of [0, 1, 5, 10, 28, 50, 100]) {
    s.permanent.prestigeCount = p;
    s.permanent.research = Object.keys(RESEARCH).slice(0, Math.min(28, p));
    validateState(s);
    const relative = efficiencyMultiplier(s) / costMultiplier(s);
    assert.ok(relative >= last && relative <= 1.35 + 1e-8);
    if (p === 28) assert.ok(relative >= 1.3);
    last = relative;
  }
  assert.ok(last > 1.34);
  assert.ok(efficiencyMultiplier(s) > costMultiplier(s));
});
test('contracts preserve job time after V3.1 upgrades; new jobs have a 30s minimum', () => {
  const base = createFactory(0);
  assert.equal(contractDuration(base, 'urgent'), 45);
  const logist = act(base, { type:'chooseRoute', id:'logistics' });
  assert.equal(contractDuration(logist, 'urgent'), 36);
  assert.equal(contractReward(logist, 'urgent').credits, 127);
  const started = act(fund(logist), { type:'startContract', id:'urgent' }, 1000);
  assert.equal(started.cycle.contract.endsAt - started.cycle.contract.startedAt, 36000);
  const next = advanceFactory(started, 37000);
  assert.equal(next.cycle.contractsCompleted, 1);
  assert.equal(next.cycle.resources.credits > started.cycle.resources.credits, true);
  const p28 = createFactory(0); p28.permanent.prestigeCount = 28;
  p28.permanent.research = Object.keys(RESEARCH);
  assert.equal(contractDuration(p28,'urgent'),30);
  assert.equal(contractDuration(p28,'scientific'),67);
  p28.permanent.prestigeCount=100;
  for(const id of Object.keys(CONTRACTS)) assert.ok(contractDuration(p28,id) >= 30);
});
test('route specializations have meaningful non-PvP economic effects',()=>{
  const s=createFactory(0);
  const base = productionRates(s);
  const science=act(s,{type:'chooseRoute',id:'scientific'});
  const priority=act(s,{type:'chooseRoute',id:'priority'});
  const industry=act(s,{type:'chooseRoute',id:'industrial'});
  assert.equal(productionRates(science).intel,base.intel*1.3);
  assert.equal(productionRates(priority).steel,base.steel*1.25);
  assert.equal(productionRates(priority).energy,base.energy*1.15);
  assert.deepEqual(productionRates(industry),base);
  assert.deepEqual(exportUnlocks(science),exportUnlocks(priority));
});
test('V3 schema 2 saved contract and research remain readable after balancing',()=>{
  const state=createFactory(1000);state.permanent.prestigeCount=5;
  state.permanent.research=Object.keys(RESEARCH).slice(0,5);
  state.cycle.route='logistics';state.cycle.contract={id:'scientific',startedAt:100,endsAt:150100};
  validateState(state);
  assert.deepEqual(decodeSave(encodeSave(state)),state);
  const after=advanceFactory(state,150100);
  assert.equal(after.cycle.contractsCompleted,1);
  assert.equal(after.permanent.research.length,5);
});
console.log('Regresiones adicionales V3.1 completadas');
