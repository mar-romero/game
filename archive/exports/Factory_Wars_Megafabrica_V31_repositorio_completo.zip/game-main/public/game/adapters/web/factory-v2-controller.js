import { SAVE_KEY, BACKUP_KEY, RESOURCES, BUILDINGS, MAX_BUILDING_LEVEL, PROJECTS, CONTRACTS, PRESTIGE_ROUTES, PRODUCTION_MODES, MODE_COOLDOWN_MS, FAMILY_NAMES, BASE_ARSENAL, ARSENAL_OPTIONS, RESEARCH } from '../../domain/factory-v2/catalog.js';
import { createFactory, advanceFactory, executeCommand, productionRates, buildingCost, projectCost, projectProgress, projectMultiplier, contractCost, contractReward, contractDuration, efficiencyMultiplier, costMultiplier, missingResources, missions, availableResearch, canPrestige, exportUnlocks } from '../../domain/factory-v2/factory-engine.js';
import { decodeSave, encodeSave } from '../../domain/factory-v2/save-format.js';

const $ = id => document.getElementById(id);
const number = value => value.toLocaleString('es-AR', { maximumFractionDigits: 1 });
const escape = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const materials = cost => Object.entries(cost).map(([key, amount]) => `${number(amount)} ${RESOURCES[key]}`).join(' · ');
let state = null;
let lastRaw = null;
let blocked = false;

function announce(message) { $('message').textContent = message; }
function storageError(message) {
  blocked = true; $('factory').hidden = true; $('storage-error').hidden = false;
  $('storage-detail').textContent = message; $('prestige-dialog').close();
  announce('La práctica está pausada para proteger el guardado.');
}
function commit(next) {
  if (localStorage.getItem(SAVE_KEY) !== lastRaw) throw new Error('El guardado cambió en otra pestaña. Volvé a cargar para usar sus datos.');
  const raw = encodeSave(next);
  localStorage.setItem(SAVE_KEY, raw);
  lastRaw = raw; state = next;
}
function load() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    lastRaw = raw;
    const now = Date.now();
    const loaded = raw === null ? createFactory(now) : decodeSave(raw);
    // One-time local backup before overwriting a V2 save with V3 schema.
    if (raw !== null && loaded.schemaVersion === 2 && JSON.parse(raw).schemaVersion === 1
        && localStorage.getItem(BACKUP_KEY) === null) localStorage.setItem(BACKUP_KEY, raw);
    const elapsed = now - loaded.savedAt;
    const next = advanceFactory(loaded, now);
    commit(next); blocked = false; $('storage-error').hidden = true; $('factory').hidden = false;
    render(); announce(elapsed >= 5000 ? 'Bienvenido. Se acreditó tu producción acumulada (máximo 4 horas) y los contratos terminados.' : 'Elegí una ruta industrial y organizá tu producción.');
  } catch (error) { storageError(`No podemos cargar o guardar la práctica. ${error.message}`); }
}
function setHTML(id, html) {
  const node = $(id);
  if (node.innerHTML !== html) {
    const focusedId = node.contains(document.activeElement) ? document.activeElement.id : null;
    node.innerHTML = html;
    if (focusedId) $(focusedId)?.focus({ preventScroll: true });
  }
}
function shortage(cost) {
  const missing = missingResources(state, cost);
  return Object.keys(missing).length ? `Falta: ${materials(missing)}` : 'Tenés los recursos necesarios.';
}
function affordable(cost) { return Object.keys(missingResources(state, cost)).length === 0; }
function render() {
  if (!state || blocked) return;
  const rates = productionRates(state);
  const relativeAdvantage = (efficiencyMultiplier(state) / costMultiplier(state) - 1) * 100;
  $('cycle-label').textContent = `Ciclo ${state.permanent.prestigeCount + 1} · ${state.permanent.prestigeCount} prestigios · requisitos ×${number(costMultiplier(state))} · producción ×${number(efficiencyMultiplier(state))} · ventaja relativa +${number(relativeAdvantage)}%`;
  const selectedRoute = state.cycle.route;
  setHTML('routes', selectedRoute ? `<p class="notice">Ruta: <strong>${PRESTIGE_ROUTES[selectedRoute].name}</strong>. ${PRESTIGE_ROUTES[selectedRoute].detail}</p>` : Object.entries(PRESTIGE_ROUTES).filter(([id]) => id !== 'legacy').map(([id, item]) => `<article class="card"><h3>${item.name}</h3><p>${item.detail}</p><button id="route-${id}" data-action="chooseRoute" data-id="${id}">Elegir esta ruta</button></article>`).join(''));
  const cooldown = state.cycle.modeChangedAt === null ? 0 : Math.max(0, Math.ceil((state.cycle.modeChangedAt + MODE_COOLDOWN_MS - state.savedAt) / 1000));
  setHTML('modes', Object.entries(PRODUCTION_MODES).map(([id, item]) => `<article class="card"><h3>${item.name}${state.cycle.mode === id ? ' · ACTIVO' : ''}</h3><p>${item.detail}</p><button id="mode-${id}" data-action="setMode" data-id="${id}" ${id === state.cycle.mode || cooldown ? 'disabled' : ''}>${id === state.cycle.mode ? 'Modo activo' : cooldown ? `Disponible en ${cooldown}s` : `Activar ${item.name}`}</button></article>`).join('')); 
  setHTML('resources', Object.entries(RESOURCES).map(([key, name]) => `<div class="resource"><span>${name}</span><strong>${number(state.cycle.resources[key])}</strong><small>+${number(rates[key])} / segundo</small></div>`).join(''));
  setHTML('buildings', Object.entries(BUILDINGS).map(([id, building]) => {
    const cost = buildingCost(state, id); const max = state.cycle.buildings[id] >= MAX_BUILDING_LEVEL;
    return `<article class="card"><div class="card-top"><h3>${building.name}</h3><span>Nivel ${state.cycle.buildings[id]}</span></div><p>Produce ${RESOURCES[building.resource]} · ${number(rates[building.resource])}/s</p><p>${max ? 'Nivel máximo.' : `Costo: ${materials(cost)}<br>${shortage(cost)}`}</p><button id="upgrade-${id}" data-action="upgrade" data-id="${id}" ${!selectedRoute || max || !affordable(cost) ? 'disabled' : ''}>Mejorar ${building.name}</button></article>`;
  }).join(''));
  const project = state.cycle.project;
  if (project) {
    const definition = PROJECTS[project.id];
    const totalCost = projectCost(state, project.id);
    const canDeliver = Object.entries(totalCost).some(([key, amount]) => amount > project.delivered[key] && state.cycle.resources[key] > 0);
    setHTML('project', `<article class="card"><h3>${definition.name}</h3><p>${definition.detail}</p><p><strong>Avance: ${number(projectProgress(state) * 100)}% · bonus actual: +${number((projectMultiplier(state) - 1) * 100)}%</strong> (hitos: 25%, 60%, 100%)</p>${Object.entries(totalCost).map(([key, amount]) => `<div class="mission">${RESOURCES[key]}: ${number(project.delivered[key])} / ${number(amount)}<progress value="${project.delivered[key]}" max="${amount}" aria-label="Entrega de ${RESOURCES[key]}"></progress></div>`).join('')}<p>${project.completed ? 'Terminado. Bonificación máxima activa hasta el próximo Prestigio.' : 'Las entregas activan bonificaciones parciales al alcanzar 25% y 60%. Cada entrega aporta materiales disponibles.'}</p>${project.completed ? '' : `<button id="deliver-project" data-action="deliverProject" ${canDeliver ? '' : 'disabled'}>Entregar materiales disponibles</button>`}</article>`);
  } else {
    setHTML('project', Object.entries(PROJECTS).map(([id, item]) => `<article class="card"><h3>${item.name}</h3><p>${item.detail}</p><p>Objetivo: ${materials(projectCost(state, id))}</p><button id="project-${id}" data-action="selectProject" data-id="${id}" ${!selectedRoute || (PRESTIGE_ROUTES[selectedRoute]?.project && PRESTIGE_ROUTES[selectedRoute].project !== id) ? 'disabled' : ''}>Elegir ${item.name}</button></article>`).join(''));
  }
  const contract = state.cycle.contract;
  $('contract-status').textContent = contract ? `${CONTRACTS[contract.id].name} en curso · ${Math.max(0, Math.ceil((contract.endsAt - state.savedAt) / 1000))} s restantes. Recompensa: ${materials(contractReward(state, contract.id))}.` : 'Cola libre. La recompensa se acredita automáticamente.';
  setHTML('contracts', Object.entries(CONTRACTS).map(([id, item]) => { const cost = contractCost(state, id); return `<article class="card"><h3>${item.name} · ${contractDuration(state, id)} s</h3><p>${item.detail}<br>Entrega: ${materials(cost)}<br>Recibís: ${materials(contractReward(state, id))}</p><p>${shortage(cost)}</p><button id="contract-${id}" data-action="startContract" data-id="${id}" ${!selectedRoute || contract || !affordable(cost) ? 'disabled' : ''}>Iniciar ${item.name}</button></article>`; }).join(''));
  $('series-status').textContent = `Serie logística: ${state.cycle.contractTypes.length}/3 tipos de contrato diferentes. ${state.cycle.seriesCompleted ? '¡Bonus de 100 Créditos y 10 Intel (ampliados por experiencia industrial) cobrado!' : 'Al completar el tercero, cobrás un bonus extra una sola vez por ciclo.'}`;
  setHTML('missions', missions(state).map(item => `<div class="mission">${item.name}: ${item.progress}/${item.target}<progress value="${item.progress}" max="${item.target}" aria-label="${item.name}"></progress></div>`).join(''));
  $('open-prestige').disabled = !canPrestige(state);
  $('prestige-reason').textContent = canPrestige(state) ? (availableResearch(state).length ? 'Misiones cumplidas. Elegí una investigación para Arena y empezá el siguiente ciclo.' : 'Ya tenés todas las investigaciones PvP. Podés prestigiar para seguir mejorando solo la fábrica.') : 'Completá las misiones de tu ruta para desbloquear el Prestigio. Los requisitos suben 20% por ciclo; tu eficiencia industrial permanente también crece, con una ventaja acumulada limitada para preservar el desafío.';
  setHTML('collection', `<p>Arsenal inicial gratuito: 4 cohetes, 4 defensas, 3 sabotajes y Reconfiguración eficiente. No cuenta como recompensa de Prestigio.</p>${Object.entries(FAMILY_NAMES).map(([family, label]) => {
    const gained = state.permanent.research.filter(key => RESEARCH[key].family === family);
    return `<div class="collection-group"><h3>${label}</h3><p class="muted">Iniciales: ${BASE_ARSENAL[family].map(id => escape(ARSENAL_OPTIONS[family][id].name)).join(', ')}</p>${gained.length ? `<ul>${gained.map(key => `<li><strong>${escape(RESEARCH[key].name)}</strong> — ${escape(RESEARCH[key].detail)}</li>`).join('')}</ul>` : '<p>Todavía no ganaste investigaciones de esta familia.</p>'}</div>`;
  }).join('')}`);
  const payload = JSON.stringify(exportUnlocks(state), null, 2);
  if ($('unlocks').value !== payload) $('unlocks').value = payload;
}

function dispatch(command) {
  if (blocked || !state) return;
  let result;
  try { result = executeCommand(state, command, Date.now()); }
  catch (error) { announce(error.message); return; }
  try { commit(result.state); }
  catch (error) { storageError(`La acción no se confirmó. ${error.message}`); return; }
  if (command.type === 'prestige') $('prestige-dialog').close();
  render(); announce(result.message);
}
$('factory').addEventListener('click', event => {
  const button = event.target.closest('button[data-action]');
  if (button) dispatch({ type: button.dataset.action, id: button.dataset.id });
});
function researchDetail() {
  const item = RESEARCH[$('research-choice').value];
  $('research-detail').textContent = item ? `${FAMILY_NAMES[item.family]} · ${item.name}: ${item.detail}` : 'Prestigio únicamente industrial: el progreso de Arena no cambia.';
}
$('open-prestige').addEventListener('click', () => {
  if (!state || blocked || !canPrestige(state)) return;
  const hasResearch = availableResearch(state).length > 0;
  $('research-choice').hidden = !hasResearch;
  $('research-label').hidden = !hasResearch;
  $('research-choice').required = hasResearch;
  $('research-choice').innerHTML = hasResearch ? Object.entries(FAMILY_NAMES).map(([family, name]) => `<optgroup label="${name}">${availableResearch(state).filter(([, item]) => item.family === family).map(([key, item]) => `<option value="${key}">${escape(item.name)}</option>`).join('')}</optgroup>`).join('') : '';
  researchDetail(); $('prestige-dialog').showModal();
});
$('research-choice').addEventListener('change', researchDetail);
$('cancel-prestige').addEventListener('click', () => $('prestige-dialog').close());
$('prestige-form').addEventListener('submit', event => { event.preventDefault(); dispatch({ type: 'prestige', research: $('research-choice').value }); });
$('copy-unlocks').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText($('unlocks').value); announce('Opciones copiadas. Arena v2 las incorpora automáticamente en la próxima preparación desde el mismo sitio y navegador.'); }
  catch { $('unlocks').focus(); $('unlocks').select(); announce('Seleccionamos el texto. Podés copiarlo manualmente.'); }
});
$('reload-save').addEventListener('click', load);
$('download-save').addEventListener('click', () => {
  let raw = lastRaw;
  try { raw = localStorage.getItem(SAVE_KEY); } catch { /* Preserve the last readable data. */ }
  if (raw === null) { announce('No hay datos guardados para descargar.'); return; }
  const url = URL.createObjectURL(new Blob([raw], { type: 'application/json' }));
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'factory-v2-guardado.json'; anchor.click(); URL.revokeObjectURL(url);
});
$('reset-save').addEventListener('click', () => {
  if (!window.confirm('¿Reiniciar Megafábrica V3? Se perderán la fábrica y las investigaciones permanentes de esta práctica. El respaldo de V2, si existe, se conserva.')) return;
  try {
    const fresh = createFactory(Date.now()); const raw = encodeSave(fresh);
    localStorage.setItem(SAVE_KEY, raw); lastRaw = raw; state = fresh; blocked = false;
    $('prestige-dialog').close(); $('storage-error').hidden = true; $('factory').hidden = false; render(); announce('Práctica reiniciada.');
  } catch (error) { storageError(`No pudimos reiniciar. ${error.message}`); }
});
window.addEventListener('storage', event => {
  if (event.key === SAVE_KEY || event.key === null) storageError('Otra pestaña cambió los datos de la práctica. Volvé a cargar para usar el guardado actual.');
});
setInterval(() => {
  if (blocked || !state) return;
  try {
    const hadActiveContract = state.cycle.contract !== null;
    const next = advanceFactory(state, Date.now());
    const contractCompleted = hadActiveContract && next.cycle.contract === null;
    commit(next); render();
    if (contractCompleted) announce('Contrato completado. La recompensa se acreditó en tu fábrica.');
  }
  catch (error) { storageError(`No podemos continuar guardando. ${error.message}`); }
}, 1000);
load();
