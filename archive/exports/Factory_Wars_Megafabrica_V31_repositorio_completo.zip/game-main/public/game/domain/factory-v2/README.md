# Megafábrica V3.1 — motor industrial y compatibilidad con Arena V2

**Entrada:** `public/factory-v2.html` (URL conservada por compatibilidad). **Dominio:** `public/game/domain/factory-v2/`; **controlador:** `public/game/adapters/web/factory-v2-controller.js`. No requiere una librería nueva ni un proceso de compilación. La Megafábrica del juego principal `public/index.html` es otra implementación y **no se ha cambiado**.

## Mecánicas nuevas (valores para playtest, no balance final)

1. **Proyectos en etapas.** Una entrega aporta todos los materiales disponibles que aún faltan. El total entregado dividido por el costo de los cuatro recursos determina el progreso. A 25% se obtiene 20% del bonus final, a 60% el 50% y a 100% el bonus completo. Ejemplo Reactor: +10% / +25% / +50% de Energía. Drones: +7% / +17.5% / +35% Créditos. Centro científico: +10% / +25% / +50% Intel. Las entregas y los bonos parciales se mantienen dentro del ciclo.
2. **Modos de producción.** Equilibrado (100% de base); Científico (+25% Intel / −15% Créditos), Pesado (+20% Acero / −10% Energía), Comercial (+20% Créditos / −15% Intel). Intervalo de 60 segundos entre cambios; el modo se mantiene al cerrar el juego y afecta a la producción offline.
3. **Contratos.** Se conservan los 3 originales y se suman Carga mayorista (120s) y Prototipo experimental (180s). Un contrato a la vez. Completar 3 **tipos diferentes** en un ciclo da una sola bonificación adicional de 100 Créditos + 10 Intel, escalados por la eficiencia industrial permanente. Los contratos especiales ayudan con la ruta Proyecto prioritario.
4. **Rutas de prestigio con identidad económica.** Se elige exactamente una ruta al comenzar el ciclo: Industrial (4 mejoras, 1 contrato, 1 proyecto); Logística (1 mejora, 4 contratos, 1 proyecto, contratos un 20% más rápidos y +15% recompensas); Científica (2 mejoras, 2 contratos, Centro científico, +30% de Intel); o Proyecto prioritario (2 mejoras, 1 contrato, 1 proyecto, 1 contrato especial, +25% Acero y +15% Energía). La elección queda bloqueada durante el ciclo. Las bonificaciones son internas a la fábrica y no afectan el PvP.
5. **Escalado V3.1.** El costo de mejoras, contratos y proyectos sigue creciendo como `1.2 ** prestigios`. La producción industrial y las recompensas de contratos crecen como `1.2 ** prestigios × (1 + 0.35 × (1 − exp(−prestigios / 12)))`. Así cada prestigio aporta ventaja permanente, pero **la ventaja relativa no supera 35%**, en lugar de crecer sin límite. Los contratos duran `máx(30 s, techo(duraciónBase × bonusRuta / (1 + 0.045 × prestigios)))`; la ruta logística aplica factor 0,8. Los valores siguen siendo parámetros **experimentales** y requieren pruebas con personas.
6. **Después de 28 investigaciones.** Se permite seguir prestigiando por eficiencia industrial, sin nuevas recompensas de Arena, hasta un límite técnico de 100 prestigios (para proteger las cotas de los números del guardado). El arsenal inicial y las opciones ya desbloqueadas se conservan.

## Guardado y migración

Se utiliza **la misma** clave `localStorage` (`factory-wars.factory-v2.local.v1`) que lee Arena V2 para desbloqueos. El formato interno ahora es `schemaVersion: 2`. `decodeSave` acepta estados V1 válidos, los convierte al esquema V3 y conserva investigaciones, recursos, niveles, entregas, contratos en curso y marca el ciclo como `legacy` para mantener las misiones 2/2/proyecto mientras dure ese ciclo. Si había un proyecto completado, se conserva como completado aunque su costo se haya escalado por el prestigio; los parcialmente terminados mantienen su proporción de materiales.

Antes de escribir la conversión de un V1 en el navegador, el controlador copia el contenido sin modificar a `localStorage['factory-wars.factory-v2.local.v1.backup-v1']` si aún no existe. Si una lectura o escritura falla, la pantalla se bloquea sin borrar el guardado. El backup reside en el **mismo navegador/origen**, no dentro de los archivos del ZIP. Exportá tus datos originales desde el botón de descarga para una copia adicional independiente.

El guardado V3 no puede abrirse con el código antiguo de Megafábrica V2. El rollback de código **no revierte el guardado**. Si revertís código, necesitás restaurar el backup V1 explícitamente. No vuelvas a V2 y sigas jugando en el mismo navegador sin antes evaluar esta incompatibilidad.

## Compatibilidad competitiva y alcance

Las mejoras de fábrica no cambian daño, salud, ingresos, recarga ni otras estadísticas de combate. Arena V2 sigue leyendo `decodeSave()` y `exportUnlocks()` en el mismo origen para desbloquear **opciones** estratégicas, no bonificaciones de poder por prestigio. El servidor histórico y la Megafábrica del juego principal `index.html` no se migran en este paquete.

## Ejecución y tests

Desde la raíz del repositorio, en PowerShell o consola:

```sh
python serve.py
```

Abrí `http://localhost:8000/factory-v2.html` y `http://localhost:8000/arena-v2.html`. Para pruebas de dominio con Node 20+:

```sh
node --experimental-default-type=module tests/factory-v3.test.mjs
```

No hay pruebas visuales automáticas ni pruebas PvP humanas en este paquete; realizar pruebas manuales en un navegador móvil antes de publicar.

## Actualización V3 → V3.1

**El esquema de guardado permanece en 2 y la clave `SAVE_KEY` no cambia.** No se resetean recursos, edificios, contratos ya iniciados ni investigaciones. Un contrato ya empezado conserva su fecha de finalización; los contratos nuevos usan la nueva curva. Los recursos disponibles anteriores permanecen, pero los multiplicadores se actualizan al cargar.

Verificá los tests con `node --experimental-default-type=module tests/factory-v3.test.mjs`; los scripts de medición en `tests/measure-factory-v3.mjs` permiten comparar los 28 prestigios. Las condiciones de PvP, servidor, Unity y la Megafábrica histórica en `index.html` no se modifican.
