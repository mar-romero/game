# Factory Wars v1.6 · Imperios · Liga 10

Prototipo web completo: Megafábrica persistente + Arena + Prestigio/Legados + cuatro rankings + Guerra de Civilizaciones + Liga 10 de 8 fechas.

## Probar local
Windows: doble clic `START_WINDOWS.bat` o ejecutá:

```powershell
python serve.py
```

Abrí `http://localhost:8000/`.

## Liga 10
Elegí una civilización. Se crea una temporada con vos y 9 bots: GREEDY, RUSHER, TURTLE, TEMPO, ADAPTIVE, RANDOM, BALANCED, HOARDER y SABOTEUR.

Todos juegan 8 partidas. La fecha NO avanza sola: primero jugás tu PvP contra otra civilización. Cuando termina, el mismo motor Arena simula las otras 4 partidas bot-vs-bot y actualiza Arena, Industrial, Imperio y Civilizaciones.

## Supabase existente
Si ya habías ejecutado el schema de v1.5.x, corré una vez:

`supabase/migrations/v160_liga10.sql`

Si es una instalación nueva, ejecutá `supabase/schema.sql` completo.

Después configurá `public/config.js` con Project URL + publishable key. Nunca pongas `service_role` en el navegador.

## GitLab Pages
El proyecto ya incluye `.gitlab-ci.yml`. Subí el repo a GitLab y el pipeline publica `public/`.

Ver `docs/DEPLOY_GITLAB_SUPABASE.md`, `docs/V160_LIGA10.md` y `docs/GAME_DESIGN_V15.md`.

## Integridad
La Liga 10 es una simulación de producto/playtest y el cliente todavía no es autoritativo. No usar resultados de esta beta para premios monetarios hasta mover validación de partidas a servidor.
